from django.contrib import admin
from event.models import Event, EmergencySituation

admin.site.register(Event)
admin.site.register(EmergencySituation)

