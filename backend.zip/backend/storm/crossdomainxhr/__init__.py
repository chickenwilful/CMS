from django_crossdomainxhr_middleware import *
