from django.contrib import admin
from storm_user.models import UserProfile

admin.site.register(UserProfile)